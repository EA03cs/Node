export const signup =  (req, res, next) => {
    res.json({ message: 'Signup endpoint' });
}

export const login =  (req, res, next) => {
    res.json({ message: 'Login endpoint' });
}